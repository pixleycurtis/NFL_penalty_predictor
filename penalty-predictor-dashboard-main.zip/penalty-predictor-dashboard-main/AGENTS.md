<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- The penalty model runs entirely in the browser: `src/lib/flags/engine.ts` is a TS port of the user's `nfl_flags.py` (simulate, crew_deltas, price_market) reading `public/model/` (current-season posterior slice as Float32 binary + meta.json). Why: no Python runtime on the edge; regenerate `public/model/` from a new posterior.npz/meta.json when the model is refit.
