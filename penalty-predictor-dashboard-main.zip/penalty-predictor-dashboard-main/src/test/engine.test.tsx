import { describe, expect, it } from "vitest";
import { priceMarket, quote, roundAmerican } from "@/lib/flags/engine";

describe("pricing (port of nfl_flags.py)", () => {
  it("rounds American odds to 5-cent steps with a floor of 100", () => {
    expect(roundAmerican(-112)).toBe(-110);
    expect(roundAmerican(97)).toBe(100);
  });
  it("applies a 7% hold to a fair 50/50 line as -115/-115", () => {
    expect(quote(0.5, 0.07)).toMatchObject({ over: -115, under: -115 });
  });
  it("puts the main line on the half-point closest to 50/50", () => {
    const sims = [...Array(50).fill(10), ...Array(50).fill(11)];
    const main = priceMarket(sims, 0.07, 0, 0.01).find((l) => l.kind === "main");
    expect(main?.line).toBe(10.5);
  });
});
