import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useModel, fmtSigned } from "@/lib/flags/use-model";

export const Route = createFileRoute("/crews")({
  head: () => ({
    meta: [
      { title: "Referee crew effects — Flag Model" },
      { name: "description", content: "How much each NFL referee crew raises or lowers the expected number of penalty flags." },
      { property: "og:title", content: "Referee crew effects — Flag Model" },
      { property: "og:description", content: "How much each NFL referee crew raises or lowers the expected number of penalty flags." },
    ],
  }),
  component: Crews,
});

const AVG_FLAGS = 15.6; // approx flags/game for converting % to flags (typical game in the current model)

function Crews() {
  const { data: model, isLoading } = useModel();
  const [all, setAll] = useState(false);
  if (isLoading || !model) return <p className="p-10 text-center text-muted-foreground">Loading model…</p>;
  const rows = model.meta.crews.filter((c) => all || c.active);
  const maxAbs = Math.max(...rows.map((r) => Math.abs(r.vs_active_avg_pct)), 1);

  return (
    <main className="mx-auto max-w-6xl px-4 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-5xl tracking-wide">Referee crews</h1>
          <p className="mt-1 max-w-2xl text-muted-foreground">
            Effect of each head referee's crew on the flag rate, compared with an average active crew. Effects are scaled to 60% (the
            backtest showed raw effects were about twice too large).
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Switch id="all" checked={all} onCheckedChange={setAll} />
          <Label htmlFor="all">Include retired referees</Label>
        </div>
      </div>

      <div className="mt-8 overflow-x-auto rounded-lg border border-border bg-card">
        <table className="w-full text-sm tabular">
          <thead className="text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr className="border-b border-border">
              <th className="p-3">Referee</th>
              <th className="p-3">Games</th>
              <th className="p-3">Last season</th>
              <th className="p-3 w-[35%]">Vs average crew</th>
              <th className="p-3 text-right">≈ Flags / game</th>
              <th className="p-3 text-right">Raw effect (80% range)</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const v = r.vs_active_avg_pct, w = (Math.abs(v) / maxAbs) * 50;
              return (
                <tr key={r.referee} className="border-b border-border/50 last:border-0 hover:bg-accent/40">
                  <td className="p-3 font-medium">
                    {r.referee}
                    {!r.active && <span className="ml-2 text-xs text-muted-foreground">retired</span>}
                  </td>
                  <td className="p-3 text-muted-foreground">{r.games ?? "—"}</td>
                  <td className="p-3 text-muted-foreground">{r.last_season ?? "—"}</td>
                  <td className="p-3">
                    <div className="relative h-4 rounded-sm bg-muted">
                      <div className="absolute inset-y-0 left-1/2 w-px bg-border" />
                      <div
                        className={`absolute inset-y-0 rounded-sm ${v >= 0 ? "bg-primary" : "bg-positive"}`}
                        style={v >= 0 ? { left: "50%", width: `${w}%` } : { right: "50%", width: `${w}%` }}
                      />
                    </div>
                  </td>
                  <td className={`p-3 text-right font-semibold ${v >= 0 ? "text-primary" : "text-positive"}`}>
                    {fmtSigned((v / 100) * AVG_FLAGS, 2)}
                  </td>
                  <td className="p-3 text-right text-muted-foreground">
                    {fmtSigned(r.raw_pct, 1)}% ({fmtSigned(r.raw_lo80, 1)} to {fmtSigned(r.raw_hi80, 1)})
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="mt-4 text-xs text-muted-foreground">
        Flags per game is approximate (effect × {AVG_FLAGS} flags). Yellow = more flags, green = fewer.
      </p>
    </main>
  );
}
