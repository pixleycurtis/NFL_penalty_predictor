import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeftRight } from "lucide-react";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import {
  TEAM_DIV, crewDeltas, pmfOf, priceMarket, simulate, sum, summarize, type GameInput, type Model,
} from "@/lib/flags/engine";
import { useModel, fmtOdds, fmtSigned } from "@/lib/flags/use-model";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Flag Model — Predict NFL penalty flags" },
      { name: "description", content: "Pick a matchup, week and referee crew to forecast penalty flags and get prop lines with odds." },
      { property: "og:title", content: "Flag Model — Predict NFL penalty flags" },
      { property: "og:description", content: "Pick a matchup, week and referee crew to forecast penalty flags and get prop lines with odds." },
    ],
  }),
  component: Index,
});

const NONE = "__none__";

function Index() {
  const { data: model, isLoading, error } = useModel();
  if (error) return <p className="p-10 text-center text-destructive">Couldn't load the model.</p>;
  if (isLoading || !model) return <p className="p-10 text-center text-muted-foreground">Loading model…</p>;
  return <Predictor model={model} />;
}

function Predictor({ model }: { model: Model }) {
  const { meta } = model;
  const [home, setHome] = useState("KC");
  const [away, setAway] = useState("BUF");
  const [week, setWeek] = useState(Math.min(18, meta.last_week + 2));
  const [referee, setReferee] = useState<string | null>(null);
  const [dome, setDome] = useState(!!meta.team_dome["KC"]);
  const [temp, setTemp] = useState(60);
  const [wind, setWind] = useState(meta.typical_wind);
  const [primetime, setPrimetime] = useState(false);
  const [hold, setHold] = useState(7);

  useEffect(() => setDome(!!meta.team_dome[home]), [home, meta]);

  const game: GameInput = {
    home, away, week, referee, dome, temp, wind, primetime, div_game: TEAM_DIV[home] === TEAM_DIV[away],
  };
  const key = JSON.stringify(game);
  const result = useMemo(() => {
    if (home === away) return null;
    const s = simulate(model, game);
    return { s, deltas: crewDeltas(model, game) };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, model]);

  const otherRefs = meta.crews.filter((c) => !c.active).map((c) => c.referee).sort();
  const activeRefs = [...meta.active_refs].sort();
  const crewRow = meta.crews.find((c) => c.referee === referee);

  return (
    <main className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="font-display text-5xl tracking-wide md:text-6xl">
        How many <span className="text-primary">flags</span> will fly?
      </h1>
      <p className="mt-1 text-muted-foreground">
        Model trained through {meta.season} week {meta.last_week}. Predictions are for the {meta.season} season.
      </p>

      <section className="mt-8 rounded-lg border border-border bg-card p-5">
        <div className="grid items-end gap-4 md:grid-cols-[1fr_auto_1fr_120px]">
          <TeamPick label="Away" value={away} onChange={setAway} teams={meta.teams} />
          <button
            type="button"
            aria-label="Swap teams"
            onClick={() => { setHome(away); setAway(home); }}
            className="mb-1 rounded-md border border-border p-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeftRight className="h-4 w-4" />
          </button>
          <TeamPick label="Home" value={home} onChange={setHome} teams={meta.teams} />
          <div>
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Week</Label>
            <Select value={String(week)} onValueChange={(v) => setWeek(+v)}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {Array.from({ length: 18 }, (_, i) => (
                  <SelectItem key={i} value={String(i + 1)}>Week {i + 1}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <div>
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Referee crew</Label>
            <Select value={referee ?? NONE} onValueChange={(v) => setReferee(v === NONE ? null : v)}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value={NONE}>Not assigned yet (average crew)</SelectItem>
                <SelectGroup>
                  <SelectLabel>Active</SelectLabel>
                  {activeRefs.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                </SelectGroup>
                <SelectGroup>
                  <SelectLabel>Retired</SelectLabel>
                  {otherRefs.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-wrap items-end gap-6 pb-2">
            <Toggle id="dome" label="Dome / closed roof" checked={dome} onChange={setDome} />
            <Toggle id="pt" label="Primetime" checked={primetime} onChange={setPrimetime} />
            <span className="text-sm text-muted-foreground">{game.div_game ? "Divisional game" : "Non-divisional"}</span>
          </div>
        </div>

        <div className="mt-4 grid gap-6 md:grid-cols-3">
          <SliderField label="Temperature" unit="°F" value={dome ? 70 : temp} min={-10} max={100} disabled={dome} onChange={setTemp} />
          <SliderField label="Wind" unit=" mph" value={dome ? 0 : wind} min={0} max={35} disabled={dome} onChange={setWind} />
          <SliderField label="Sportsbook margin" unit="%" value={hold} min={0} max={15} onChange={setHold} />
        </div>
      </section>

      {home === away && <p className="mt-6 text-destructive">Pick two different teams.</p>}

      {result && (
        <Results game={game} s={result.s} deltas={result.deltas} hold={hold / 100} crewPct={crewRow?.vs_active_avg_pct} />
      )}

      <p className="mt-10 border-t border-border pt-4 text-xs text-muted-foreground">
        Model-generated reference prices, not sportsbook data. "Flags thrown" excludes flags that were picked up. Backtests show the model
        ties a naive league-average-by-week baseline: do not treat these as edges.
      </p>
    </main>
  );
}

function Results({ game, s, deltas, hold, crewPct }: {
  game: GameInput; s: ReturnType<typeof simulate>; deltas: number[] | null; hold: number; crewPct?: number | undefined;
}) {
  const gt = sum(s.fh, s.fa), ga = sum(s.ah, s.aa);
  const markets = [
    { label: "Flags thrown — game", s: gt, d: deltas?.[0], big: true },
    { label: "Accepted — game", s: ga, d: deltas?.[3], big: true },
    { label: `${game.away} flags thrown`, s: s.fa, d: deltas?.[2] },
    { label: `${game.home} flags thrown`, s: s.fh, d: deltas?.[1] },
    { label: `${game.away} accepted`, s: s.aa, d: deltas?.[5] },
    { label: `${game.home} accepted`, s: s.ah, d: deltas?.[4] },
  ];
  const sg = summarize(gt);

  return (
    <section className="mt-8 space-y-6">
      <div className="grid gap-6 rounded-lg border border-border bg-card p-6 md:grid-cols-[auto_1fr]">
        <div>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">{game.away} @ {game.home} · Week {game.week}</p>
          <p className="font-display text-8xl leading-none text-primary tabular">{sg.mean.toFixed(1)}</p>
          <p className="text-muted-foreground">expected flags thrown</p>
          <p className="mt-2 text-sm">80% of games: <b className="tabular">{sg.p10}–{sg.p90}</b></p>
          <p className="mt-3 text-sm">
            {game.referee ? (
              <>
                {game.referee}'s crew:{" "}
                <b className={(deltas?.[0] ?? 0) >= 0 ? "text-primary" : "text-positive"}>{fmtSigned(deltas?.[0] ?? 0)} flags</b>
                {crewPct !== undefined && <span className="text-muted-foreground"> ({fmtSigned(crewPct, 1)}%)</span>}
              </>
            ) : (
              <span className="text-muted-foreground">Crew not assigned: averaged over active crews</span>
            )}
          </p>
        </div>
        <Histogram s={gt} />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {markets.map((m) => <MarketCard key={m.label} {...m} hold={hold} />)}
      </div>
    </section>
  );
}

function MarketCard({ label, s, d, hold }: { label: string; s: Int16Array; d?: number | undefined; hold: number }) {
  const sm = summarize(s);
  const lines = priceMarket(s, hold, 2);
  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="flex items-baseline justify-between">
        <h3 className="font-display text-2xl tracking-wide">{label}</h3>
        <span className="text-sm text-muted-foreground tabular">
          exp <b className="text-foreground">{sm.mean.toFixed(2)}</b> · 80% {sm.p10}–{sm.p90}
          {d !== undefined && <> · crew {fmtSigned(d)}</>}
        </span>
      </div>
      <table className="mt-3 w-full text-sm tabular">
        <thead className="text-xs uppercase tracking-wider text-muted-foreground">
          <tr><th className="py-1 text-left">Line</th><th className="text-right">Over</th><th className="text-right">Under</th><th className="text-right">Fair P(over)</th></tr>
        </thead>
        <tbody>
          {lines.map((l) => (
            <tr key={l.line} className={l.kind === "main" ? "bg-primary/10 font-semibold" : "text-muted-foreground"}>
              <td className="py-1 pl-1">{l.line.toFixed(1)} {l.kind === "main" && <span className="ml-1 text-xs text-primary">MAIN</span>}</td>
              <td className="text-right">{fmtOdds(l.over)}</td>
              <td className="text-right">{fmtOdds(l.under)}</td>
              <td className="pr-1 text-right">{(l.pOver * 100).toFixed(1)}%</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Histogram({ s }: { s: Int16Array }) {
  const { lo, pmf } = pmfOf(s);
  const max = Math.max(...pmf);
  const bars = pmf.map((p, i) => ({ x: lo + i, p })).filter((b) => b.p > 0.002);
  return (
    <div className="flex h-56 items-end gap-[2px]">
      {bars.map((b) => (
        <div key={b.x} className="group flex flex-1 flex-col items-center justify-end" title={`${b.x} flags: ${(b.p * 100).toFixed(1)}%`}>
          <div className="w-full rounded-t-sm bg-primary/70 transition-colors group-hover:bg-primary" style={{ height: `${(b.p / max) * 190}px` }} />
          <span className="mt-1 text-[10px] text-muted-foreground tabular">{b.x % 2 === 0 ? b.x : ""}</span>
        </div>
      ))}
    </div>
  );
}

function TeamPick({ label, value, onChange, teams }: { label: string; value: string; onChange: (v: string) => void; teams: string[] }) {
  return (
    <div>
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="mt-1 font-display text-2xl tracking-wide"><SelectValue /></SelectTrigger>
        <SelectContent>
          {teams.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
  );
}

function Toggle({ id, label, checked, onChange }: { id: string; label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center gap-2">
      <Switch id={id} checked={checked} onCheckedChange={onChange} />
      <Label htmlFor={id}>{label}</Label>
    </div>
  );
}

function SliderField({ label, unit, value, min, max, disabled, onChange }: {
  label: string; unit: string; value: number; min: number; max: number; disabled?: boolean | undefined; onChange: (v: number) => void;
}) {
  return (
    <div className={disabled ? "opacity-50" : ""}>
      <div className="flex justify-between text-xs uppercase tracking-wider text-muted-foreground">
        <span>{label}</span><span className="text-foreground tabular">{value}{unit}</span>
      </div>
      <Slider className="mt-3" value={[value]} min={min} max={max} step={1} disabled={!!disabled} onValueChange={(v) => onChange(v[0] ?? value)} />
    </div>
  );
}
