import { useQuery } from "@tanstack/react-query";
import { loadModel } from "./engine";

export function useModel() {
  return useQuery({ queryKey: ["flag-model"], queryFn: loadModel, staleTime: Infinity, gcTime: Infinity });
}

export const fmtOdds = (o: number) => (o > 0 ? `+${o}` : `${o}`);
export const fmtSigned = (x: number, d = 2) => `${x >= 0 ? "+" : ""}${x.toFixed(d)}`;
