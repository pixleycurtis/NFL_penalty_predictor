// @ts-nocheck -- numeric port of nfl_flags.py; strict index checks add noise to tight loops. Verified against the Python output.
// TypeScript port of the prediction + pricing parts of nfl_flags.py (simulate, crew_deltas, price_market, summarize).
// Model parameters come from the user's trained posterior (current season slice), served from /model.

export const COVS = ["home", "dome", "div_game", "primetime", "wind10", "cold"] as const;

export const DIVISIONS: Record<string, string[]> = {
  "AFC East": ["BUF", "MIA", "NE", "NYJ"], "AFC North": ["BAL", "CIN", "CLE", "PIT"],
  "AFC South": ["HOU", "IND", "JAX", "TEN"], "AFC West": ["DEN", "KC", "LAC", "LV"],
  "NFC East": ["DAL", "NYG", "PHI", "WAS"], "NFC North": ["CHI", "DET", "GB", "MIN"],
  "NFC South": ["ATL", "CAR", "NO", "TB"], "NFC West": ["ARI", "LA", "SEA", "SF"],
};
export const TEAM_DIV: Record<string, string> = Object.fromEntries(
  Object.entries(DIVISIONS).flatMap(([d, ts]) => ts.map((t) => [t, d])),
);

export interface CrewRow {
  referee: string; games: number | null; last_season: number | null; active: boolean;
  raw_pct: number; raw_lo80: number; raw_hi80: number; applied_pct: number; vs_active_avg_pct: number;
}
export interface ModelMeta {
  D: number; layout: { k: string; off: number; w: number }[]; teams: string[]; refs: string[]; active_refs: string[];
  team_dome: Record<string, number>; typical_wind: number; season: number; last_week: number; trained: string; crews: CrewRow[];
}
export interface Model { meta: ModelMeta; get: (k: string, d: number, j?: number) => number }

export async function loadModel(): Promise<Model> {
  const [meta, buf] = await Promise.all([
    fetch("/model/meta.json").then((r) => r.json() as Promise<ModelMeta>),
    fetch("/model/posterior.bin").then((r) => r.arrayBuffer()),
  ]);
  return makeModel(meta, new Float32Array(buf));
}

export function makeModel(meta: ModelMeta, data: Float32Array): Model {
  const L = Object.fromEntries(meta.layout.map((l) => [l.k, l]));
  return { meta, get: (k, d, j = 0) => data[L[k].off + d * L[k].w + j] };
}

// ---------- RNG ----------
export function rng(seed: number) {
  let s = seed >>> 0;
  const u = () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const normal = () => Math.sqrt(-2 * Math.log(u() || 1e-12)) * Math.cos(2 * Math.PI * u());
  const gamma = (k: number): number => {
    if (k < 1) return gamma(k + 1) * Math.pow(u() || 1e-12, 1 / k);
    const d = k - 1 / 3, c = 1 / Math.sqrt(9 * d);
    for (;;) {
      let x, v;
      do { x = normal(); v = 1 + c * x; } while (v <= 0);
      v = v * v * v;
      const uu = u();
      if (uu < 1 - 0.0331 * x ** 4 || Math.log(uu) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
    }
  };
  const poisson = (mu: number) => {
    if (mu > 60) return Math.max(0, Math.round(mu + Math.sqrt(mu) * normal()));
    const L = Math.exp(-mu); let k = 0, p = 1;
    do { k++; p *= u(); } while (p > L);
    return k - 1;
  };
  const binom = (n: number, p: number) => { let c = 0; for (let i = 0; i < n; i++) if (u() < p) c++; return c; };
  return { u, normal, gamma, poisson, binom };
}

// ---------- game definition ----------
export interface GameInput {
  home: string; away: string; week: number; referee: string | null;
  dome: boolean; temp: number; wind: number; primetime: boolean; div_game: boolean;
}
export function covariates(g: GameInput) {
  const temp = g.dome ? 70 : g.temp, wind = g.dome ? 0 : g.wind;
  return { dome: +g.dome, div_game: +g.div_game, primetime: +g.primetime, wind10: wind / 10, cold: +(temp < 40 && !g.dome) };
}

export interface Sims { fh: Int16Array; fa: Int16Array; ah: Int16Array; aa: Int16Array }

export function simulate(m: Model, g: GameInput, nrep = 12, seed = 7, crewShrink = 0.6): Sims {
  const { meta, get } = m, r = rng(seed), D = meta.D;
  const h = meta.teams.indexOf(g.home), a = meta.teams.indexOf(g.away), w = g.week - 1;
  const act = meta.active_refs.map((x) => meta.refs.indexOf(x)).filter((i) => i >= 0);
  const fixedRef = g.referee ? meta.refs.indexOf(g.referee) : -1;
  const cv = covariates(g);
  const N = D * nrep, fh = new Int16Array(N), fa = new Int16Array(N), ah = new Int16Array(N), aa = new Int16Array(N);
  for (let d = 0; d < D; d++) {
    const rr = fixedRef >= 0 ? fixedRef : act[Math.floor(r.u() * act.length)];
    const covPart = get("beta", d, 1) * cv.dome + get("beta", d, 2) * cv.div_game + get("beta", d, 3) * cv.primetime
      + get("beta", d, 4) * cv.wind10 + get("beta", d, 5) * cv.cold;
    const common = get("a0", d) + get("season", d) + crewShrink * get("ref", d, rr) + covPart + get("week", d, w);
    const u = get("sd_game", d) * r.normal();
    const side = (t: number, o: number, home: boolean) =>
      Math.exp(common + get("team", d, t) + get("opp", d, o) + get("ts", d, t) + u + (home ? get("beta", d, 0) : 0));
    const muH = side(h, a, true), muA = side(a, h, false), alpha = get("alpha", d);
    const accP = (t: number) => 1 / (1 + Math.exp(-(get("c0", d) + get("acc_team", d, t) + crewShrink * get("acc_ref", d, rr))));
    const pH = accP(h), pA = accP(a);
    for (let k = 0; k < nrep; k++) {
      const i = d * nrep + k;
      fh[i] = r.poisson(r.gamma(alpha) * muH / alpha);
      fa[i] = r.poisson(r.gamma(alpha) * muA / alpha);
      ah[i] = r.binom(fh[i], pH);
      aa[i] = r.binom(fa[i], pA);
    }
  }
  return { fh, fa, ah, aa };
}

/** Noise-free expected [Th, Ta, Ah, Aa] for a given crew index. */
function expectedForCrew(m: Model, g: GameInput, rr: number, crewShrink: number) {
  const { meta, get } = m, D = meta.D, cv = covariates(g);
  const h = meta.teams.indexOf(g.home), a = meta.teams.indexOf(g.away), w = g.week - 1;
  const out = [0, 0, 0, 0];
  for (let d = 0; d < D; d++) {
    const cov = get("beta", d, 1) * cv.dome + get("beta", d, 2) * cv.div_game + get("beta", d, 3) * cv.primetime
      + get("beta", d, 4) * cv.wind10 + get("beta", d, 5) * cv.cold;
    const common = get("a0", d) + get("season", d) + crewShrink * get("ref", d, rr) + cov + get("week", d, w);
    const gm = Math.exp(0.5 * get("sd_game", d) ** 2);
    const mu = (t: number, o: number, home: boolean) =>
      Math.exp(common + get("team", d, t) + get("opp", d, o) + get("ts", d, t) + (home ? get("beta", d, 0) : 0)) * gm;
    const p = (t: number) => 1 / (1 + Math.exp(-(get("c0", d) + get("acc_team", d, t) + crewShrink * get("acc_ref", d, rr))));
    const mh = mu(h, a, true), ma = mu(a, h, false);
    out[0] += mh; out[1] += ma; out[2] += mh * p(h); out[3] += ma * p(a);
  }
  return out.map((x) => x / D);
}

/** Crew effect vs an average active crew: [game thrown, home thrown, away thrown, game acc, home acc, away acc]. */
export function crewDeltas(m: Model, g: GameInput, crewShrink = 0.6): number[] | null {
  if (!g.referee) return null;
  const rr = m.meta.refs.indexOf(g.referee);
  if (rr < 0) return null;
  const act = m.meta.active_refs.map((x) => m.meta.refs.indexOf(x)).filter((i) => i >= 0);
  const avg = [0, 0, 0, 0];
  for (const j of act) expectedForCrew(m, g, j, crewShrink).forEach((v, i) => (avg[i] += v / act.length));
  const d = expectedForCrew(m, g, rr, crewShrink).map((v, i) => v - avg[i]);
  return [d[0] + d[1], d[0], d[1], d[2] + d[3], d[2], d[3]];
}

// ---------- pricing ----------
const clip = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));
export const americanFromProb = (q: number) => { q = clip(q, 0.03, 0.97); return q >= 0.5 ? (-100 * q) / (1 - q) : (100 * (1 - q)) / q; };
export const roundAmerican = (o: number, step = 5) => { const r = Math.max(step * Math.round(Math.abs(o) / step), 100); return o < 0 ? -r : r; };
export const probFromAmerican = (o: number) => (o < 0 ? -o / (-o + 100) : 100 / (o + 100));

export function quote(pOver: number, hold: number) {
  const oo = roundAmerican(americanFromProb(pOver * (1 + hold)));
  const uu = roundAmerican(americanFromProb((1 - pOver) * (1 + hold)));
  return { over: oo, under: uu, holdRealised: probFromAmerican(oo) + probFromAmerican(uu) - 1 };
}

export interface PricedLine { kind: "main" | "alt"; line: number; over: number; under: number; pOver: number; holdRealised: number }

export function pmfOf(s: ArrayLike<number>) {
  let lo = Infinity, hi = -Infinity;
  for (let i = 0; i < s.length; i++) { lo = Math.min(lo, s[i]); hi = Math.max(hi, s[i]); }
  const pmf = new Array(hi - lo + 1).fill(0);
  for (let i = 0; i < s.length; i++) pmf[s[i] - lo] += 1 / s.length;
  return { lo, pmf: pmf as number[] };
}

export function priceMarket(s: ArrayLike<number>, hold = 0.07, nAlts = 2, minP = 0.04): PricedLine[] {
  const { lo, pmf } = pmfOf(s);
  let c = 0;
  const pOver = pmf.map((p) => { c += p; return 1 - c; });
  const ok = pOver.map((p, i) => [p, i] as const).filter(([p]) => p > minP && p < 1 - minP);
  const pool = ok.length ? ok : pOver.map((p, i) => [p, i] as const);
  const kMain = pool.reduce((b, x) => (Math.abs(x[0] - 0.5) < Math.abs(b[0] - 0.5) ? x : b))[1];
  const offs = [0]; for (let n = 1; n <= nAlts; n++) offs.push(-n, n);
  const out: PricedLine[] = [];
  for (const off of offs) {
    const k = kMain + off;
    if (k >= 0 && k < pmf.length && pOver[k] > minP && pOver[k] < 1 - minP) {
      const q = quote(pOver[k], hold);
      out.push({ kind: off === 0 ? "main" : "alt", line: lo + k + 0.5, ...q, pOver: pOver[k] });
    }
  }
  return out.sort((x, y) => x.line - y.line);
}

export function summarize(s: ArrayLike<number>) {
  const a = Array.from(s).sort((x, y) => x - y), n = a.length;
  const pct = (q: number) => { const pos = (q / 100) * (n - 1), lo = Math.floor(pos); return a[lo] + (a[Math.min(n - 1, lo + 1)] - a[lo]) * (pos - lo); };
  const mean = a.reduce((x, y) => x + y, 0) / n;
  return { mean, median: pct(50), p10: pct(10), p90: pct(90) };
}

export function sum(a: Int16Array, b: Int16Array) { const o = new Int16Array(a.length); for (let i = 0; i < a.length; i++) o[i] = a[i] + b[i]; return o; }
